#pragma once

namespace UserInterface {
    void playGame();
}

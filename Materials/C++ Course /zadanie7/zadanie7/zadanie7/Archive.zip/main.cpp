#include "UserInterface.hpp"

int main() {
    UserInterface::playGame();
    return 0;
}
